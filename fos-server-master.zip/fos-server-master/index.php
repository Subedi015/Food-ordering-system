<?php

?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>FOOD ORDERING SYSTEM SERVER</title>

</head>
<body>

  <div>
    <p>It was popularised in the 1960s with the release of 
    Letraset sheets containing Lorem Ipsum passages, 
    and more recently with desktop publishing software like 
    Aldus PageMaker including versions of Lorem Ipsum.</p>
   
  </div>
  
</body>
</html>