<?php
  /*
  * This is all constants which may be used at different places
  */
  define ('DB_HOST', 'localhost');
  define ('DB_USER', 'root');
  define ('DB_PASS', 'root');
  define ('DB_NAME', 'fos_database');

?>